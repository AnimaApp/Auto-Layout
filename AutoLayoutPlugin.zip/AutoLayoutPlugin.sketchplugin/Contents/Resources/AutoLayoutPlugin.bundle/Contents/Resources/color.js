
var color_data = function(color) {
  return {
    "red": [color red],
    "green": [color green],
    "blue": [color blue],
    "alpha": [color alpha],
    "model_class": "ADModelColor"
  };
}

var clear_color_data = {
  "red": 1,
  "green": 1,
  "blue": 1,
  "alpha": 0,
  "model_class": "ADModelColor"
}

var white_color_data = {
  "red": 1,
  "green": 1,
  "blue": 1,
  "alpha": 1,
  "model_class": "ADModelColor"
}