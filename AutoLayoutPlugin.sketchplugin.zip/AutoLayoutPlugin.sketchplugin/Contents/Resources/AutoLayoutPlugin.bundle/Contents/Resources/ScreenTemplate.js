var screenTemplate = [
  {"category":"iOS",
  "templates":[
               {
               "name":"iPhone 6",
               "width":750,
               "height":1334,
               "scale":2
               },
               {
               "name":"iPhone 6 Plus",
               "width":1242,
               "height":2208,
               "scale":3
               },
               {
               "name":"iPhone 5",
               "width":640,
               "height":1136,
               "scale":2
               },
               {
               "name":"iPad Air",
               "width":1536,
               "height":2048,
               "scale":2
               },
               {
               "name":"iPad Pro",
               "width":2048,
               "height":2732,
               "scale":2
               }
               ]
  }
  ]